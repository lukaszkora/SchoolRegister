﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Membership.OpenAuth;

namespace LKORA_DziennikElektroniczny
{
    public partial class OcenyUczen : System.Web.UI.Page
    {
        EntitiesDziennik entitycontext = new EntitiesDziennik();
        SqlDataSource sqlcontext = new SqlDataSource();


        protected void Page_Load(object sender, EventArgs e)
        {
            string guidUzytkownikaString = Membership.GetUser().ProviderUserKey.ToString();   //Pobieranie UserID rejestrowanego użytkownika do tabeli Nauczyciele/Uczniowie/RodziceOpiekunowie
            Guid uczenGuid = new Guid(guidUzytkownikaString);

            var uczen = (from a in entitycontext.Uczniowie
                            where a.UserId == uczenGuid
                            select a.IdUcznia).FirstOrDefault();

            string idUcznia = Convert.ToString(uczen);
            //this.Label1.Text = idUcznia;

            string stringSelectCommand = "SELECT Uczniowie.Imie AS Imię, Uczniowie.Nazwisko, Klasy.NazwaKlasy AS Klasa, Oceny.OcenaWidok AS Ocena, RodzajeOcen.NazwaRodzajuOceny AS [Rodzaj oceny], Przedmioty.NazwaPrzedmiotu AS Przedmiot FROM Klasy INNER JOIN Oceny ON Klasy.IdKlasy = Oceny.IdKlasy INNER JOIN Przedmioty ON Oceny.IdPrzedmiotu = Przedmioty.IdPrzedmiotu INNER JOIN RodzajeOcen ON Oceny.IdRodzajuOceny = RodzajeOcen.IdRodzajuOceny INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy AND Oceny.IdUcznia = Uczniowie.IdUcznia WHERE (Uczniowie.IdUcznia = " + idUcznia + ")";
            this.SqlDataSource1.SelectCommand = stringSelectCommand;

            //SELECT Uczniowie.Imie AS Imię, Uczniowie.Nazwisko, Klasy.NazwaKlasy AS Klasa, Oceny.OcenaWidok AS Ocena, RodzajeOcen.NazwaRodzajuOceny AS [Rodzaj oceny], Przedmioty.NazwaPrzedmiotu AS Przedmiot FROM Klasy INNER JOIN Oceny ON Klasy.IdKlasy = Oceny.IdKlasy INNER JOIN Przedmioty ON Oceny.IdPrzedmiotu = Przedmioty.IdPrzedmiotu INNER JOIN RodzajeOcen ON Oceny.IdRodzajuOceny = RodzajeOcen.IdRodzajuOceny INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy AND Oceny.IdUcznia = Uczniowie.IdUcznia                             WHERE (Uczniowie.IdUcznia = 65)"
        }
    }
}