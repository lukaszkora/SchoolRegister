﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LKORA_DziennikElektroniczny
{
    public partial class Klasy1 : System.Web.UI.Page
    {
        EntitiesDziennik entitycontext = new EntitiesDziennik();
        SqlDataSource sqlcontext = new SqlDataSource();


        protected void Page_Load(object sender, EventArgs e)
        {
            this.GridViewWszystkieKlasy.Visible = false;
            this.GridViewLiczebnosc.Visible = false;
            this.LabelLiczbaUczniow.Visible = false;
        }


        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedIndex == 0)
            {
                this.GridViewWszystkieKlasy.Visible = false;
                this.GridViewLiczebnosc.Visible = false;
                this.LabelLiczbaUczniow.Visible = false;
            }


            if (DropDownList1.SelectedIndex == 1)
            {
                this.SqlDataSourceWszyscyUczniowie.SelectCommand = "SELECT Uczniowie.Imie, Uczniowie.Nazwisko, Uczniowie.Pesel, Klasy.NazwaKlasy FROM Klasy INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy";
                this.GridViewWszystkieKlasy.Visible = true;
                this.SqlDataSourceLiczebnosc.SelectCommand = "SELECT COUNT(IdUcznia) AS [Liczba uczniow] FROM Uczniowie";
                this.GridViewLiczebnosc.Visible = true;
                this.LabelLiczbaUczniow.Visible = true;
            }

            if (DropDownList1.SelectedIndex == 2)
            {
                this.SqlDataSourceWszyscyUczniowie.SelectCommand = "SELECT Uczniowie.Imie, Uczniowie.Nazwisko, Uczniowie.Pesel, Klasy.NazwaKlasy FROM Klasy INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy WHERE (Klasy.NazwaKlasy = 4)";
                this.GridViewWszystkieKlasy.Visible = true;
                this.SqlDataSourceLiczebnosc.SelectCommand = "SELECT COUNT(Uczniowie.IdUcznia) AS [Liczba uczniow] FROM Klasy INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy WHERE (Klasy.NazwaKlasy = 4)";
                this.GridViewLiczebnosc.Visible = true;
                this.LabelLiczbaUczniow.Visible = true;
            }

            if (DropDownList1.SelectedIndex == 3)
            {
                this.SqlDataSourceWszyscyUczniowie.SelectCommand = "SELECT Uczniowie.Imie, Uczniowie.Nazwisko, Uczniowie.Pesel, Klasy.NazwaKlasy FROM Klasy INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy WHERE (Klasy.NazwaKlasy = 5)";
                this.GridViewWszystkieKlasy.Visible = true;
                this.SqlDataSourceLiczebnosc.SelectCommand = "SELECT COUNT(Uczniowie.IdUcznia) AS [Liczba uczniow] FROM Klasy INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy WHERE (Klasy.NazwaKlasy = 5)";
                this.GridViewLiczebnosc.Visible = true;
                this.LabelLiczbaUczniow.Visible = true;
            }

            if (DropDownList1.SelectedIndex == 4)
            {
                this.SqlDataSourceWszyscyUczniowie.SelectCommand = "SELECT Uczniowie.Imie, Uczniowie.Nazwisko, Uczniowie.Pesel, Klasy.NazwaKlasy FROM Klasy INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy WHERE (Klasy.NazwaKlasy = 6)";
                this.GridViewWszystkieKlasy.Visible = true;
                this.SqlDataSourceLiczebnosc.SelectCommand = "SELECT COUNT(Uczniowie.IdUcznia) AS [Liczba uczniow] FROM Klasy INNER JOIN Uczniowie ON Klasy.IdKlasy = Uczniowie.IdKlasy WHERE (Klasy.NazwaKlasy = 6)";
                this.GridViewLiczebnosc.Visible = true;
                this.LabelLiczbaUczniow.Visible = true;
            }
        }
    }
}