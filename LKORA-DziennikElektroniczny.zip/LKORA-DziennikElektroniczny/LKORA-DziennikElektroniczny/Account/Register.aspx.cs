﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Membership.OpenAuth;


namespace LKORA_DziennikElektroniczny.Account
{
    public partial class Register : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            RegisterUser.ContinueDestinationPageUrl = Request.QueryString["ReturnUrl"];
        }


        protected void RegisterUser_CreatedUser(object sender, EventArgs e)
        {
            /* Dodawanie dodatkowych danych do tworzonego profilu */

            //Rejestracja nowych pól w CreateUserWizard  -  bez tego nie są w ogóle "widziane"
            DropDownList DropDownListRodzajUzytkownika = (DropDownList)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("DropDownListRodzajUzytkownika");
            TextBox TextBoxImie = (TextBox)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("TextBoxImie");
            TextBox TextBoxNazwisko = (TextBox)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("TextBoxNazwisko");
            TextBox TextBoxDataUrodzenia = (TextBox)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("TextBoxDataUrodzenia");
            TextBox TextBoxPESEL = (TextBox)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("TextBoxPESEL");
            DropDownList DropDownListPlec = (DropDownList)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("DropDownListPlec");
            TextBox TextBoxTytul = (TextBox)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("TextBoxTytul");
            DropDownList DropDownListKlasa = (DropDownList)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("DropDownListKlasa");
            DropDownList DropDownListRokSzkolny = (DropDownList)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("DropDownListRokSzkolny");
            Label LabelRejestracjaKomunikat = (Label)RegisterUser.CreateUserStep.ContentTemplateContainer.FindControl("LabelRejestracjaKomunikat");
            
            //Deklaracja zmiennych tworzonego profilu
            string email = Membership.GetUser(RegisterUser.UserName).Email.ToString();   //Pobieranie adresu E-mail rejestrowanego użytkownika do tabeli Nauczyciele/Uczniowie/RodziceOpiekunowie
            string userName = Membership.GetUser(RegisterUser.UserName).UserName.ToString();   ////Pobieranie UserName rejestrowanego użytkownika do tabeli Nauczyciele/Uczniowie/RodziceOpiekunowie
            string guidUzytkownikastring = Membership.GetUser(RegisterUser.UserName).ProviderUserKey.ToString();   //Pobieranie UserID rejestrowanego użytkownika do tabeli Nauczyciele/Uczniowie/RodziceOpiekunowie
            Guid guidUzytkownika = new Guid(guidUzytkownikastring);            
            string imie = TextBoxImie.Text;   //Imię rejestrowanego użytkownika
            string nazwisko = TextBoxNazwisko.Text;   //Nazwisko rejestrowanego użytkownika
            string rodzajUzytkownika = DropDownListRodzajUzytkownika.Text;   //Rodzaj użytkownika: Nauczyciel, Uczeń lub Rodzic/Opiekun            
            string data = TextBoxDataUrodzenia.Text;
            DateTime dataUrodzenia = Convert.ToDateTime(data);   //Konwersja formatu string pola DataUrodzenia na format daty
            string pesel = TextBoxPESEL.Text;
            string plec = DropDownListPlec.Text;   //Płeć użytkownika: chłopak/mężczyzna  lub  dziewczyna/kobieta
            string tytul = TextBoxTytul.Text;
            string klasa = DropDownListKlasa.Text;
            string rokSzkolny = DropDownListRokSzkolny.Text;
            

            EntitiesDziennik context = new EntitiesDziennik();
            var Y = (from c in context.Klasy
                     where c.NazwaKlasy == klasa
                     && c.RokSzkolny == rokSzkolny
                     select c.IdKlasy).FirstOrDefault();   //Pobieranie z bazy IdKlasy w celu zapisania w tabeli Uczniowie, na podstawie podanych przez użytkownika parametrów (klasa i rokSzkolny)


            if (rodzajUzytkownika == "Uczen")
            {
                try
                {
                    Uczniowie uczen = new Uczniowie();
                    uczen.Email = email;
                    uczen.UserName = userName;
                    uczen.UserId = guidUzytkownika;
                    uczen.Imie = imie;
                    uczen.Nazwisko = nazwisko;                    
                    uczen.DataUrodzenia = dataUrodzenia;
                    uczen.Pesel = pesel;
                    uczen.Plec = plec;
                    uczen.IdKlasy = Y;
                    context.Uczniowie.Add(uczen);
                    context.SaveChanges();
                    context.Dispose();
                    LabelRejestracjaKomunikat.Text = "OK!";
                }
                catch
                {
                    LabelRejestracjaKomunikat.Text = "Błąd!";
                }
            }

            if (rodzajUzytkownika == "Nauczyciel")
            {
                try
                {
                    Nauczyciele nauczyciel = new Nauczyciele();
                    nauczyciel.Email = email;
                    nauczyciel.UserName = userName;
                    nauczyciel.UserId = guidUzytkownika;
                    nauczyciel.Imie = imie;
                    nauczyciel.Nazwisko = nazwisko;                    
                    nauczyciel.DataUrodzenia = dataUrodzenia;
                    nauczyciel.Pesel = pesel;
                    nauczyciel.Plec = plec;
                    nauczyciel.Tytul = tytul;
                    context.Nauczyciele.Add(nauczyciel);
                    context.SaveChanges();
                    context.Dispose();
                    LabelRejestracjaKomunikat.Text = "OK!";
                }
                catch
                {
                    LabelRejestracjaKomunikat.Text = "Błąd!";
                }
            }

            //FormsAuthentication.SetAuthCookie(RegisterUser.UserName, createPersistentCookie: false);   //zakomentowane = wyłączone automatyczne logowanie użytkownika po udanej rejestracji
            string continueUrl = RegisterUser.ContinueDestinationPageUrl;
            if (!OpenAuth.IsLocalUrl(continueUrl))
            {
                continueUrl = "/WyborPoRejestracji.aspx";
            }
            Response.Redirect(continueUrl);       
        }
    }
}