﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.AspNet.Membership.OpenAuth;

namespace LKORA_DziennikElektroniczny
{
    public partial class Oceny1 : System.Web.UI.Page
    {
        EntitiesDziennik entitycontext = new EntitiesDziennik();
        SqlDataSource sqlcontext = new SqlDataSource();
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //załadowanie danych z bazy do DropDownListOcenyPrzedmiot
                var przedmiot = from a in entitycontext.Przedmioty select new { a.IdPrzedmiotu, a.NazwaPrzedmiotu };
                DropDownListOcenyPrzedmiot.DataSource = przedmiot.ToList();
                DropDownListOcenyPrzedmiot.DataValueField = "IdPrzedmiotu";
                DropDownListOcenyPrzedmiot.DataTextField = "NazwaPrzedmiotu";
                DropDownListOcenyPrzedmiot.DataBind();
                DropDownListOcenyPrzedmiot.Items.Insert(0, "--Wybierz--");

                //załadowanie danych z bazy do DropDownListOcenyKlasa
                var klasa = from b in entitycontext.Klasy select new { b.IdKlasy, b.NazwaKlasy };
                DropDownListOcenyKlasa.DataSource = klasa.ToList();
                DropDownListOcenyKlasa.Enabled = true;
                DropDownListOcenyKlasa.DataValueField = "IdKlasy";
                DropDownListOcenyKlasa.DataTextField = "NazwaKlasy";
                DropDownListOcenyKlasa.DataBind();
                DropDownListOcenyKlasa.Items.Insert(0, "--Wybierz--");
                DropDownListOcenyUczen.Enabled = false;

                //załadowanie danych z bazy do DropDownListOcenyRodzajOceny
                var rodzajOceny = from g in entitycontext.RodzajeOcen select new { g.IdRodzajuOceny, g.NazwaRodzajuOceny };
                DropDownListOcenyRodzajOceny.DataSource = rodzajOceny.ToList();
                DropDownListOcenyRodzajOceny.Enabled = true;
                DropDownListOcenyRodzajOceny.DataValueField = "IdRodzajuOceny";
                DropDownListOcenyRodzajOceny.DataTextField = "NazwaRodzajuOceny";
                DropDownListOcenyRodzajOceny.DataBind();
                DropDownListOcenyRodzajOceny.Items.Insert(0, "--Wybierz--");

                this.Label1.Visible = false; this.Label2.Visible = false; this.Label3.Visible = false;
                this.Label4.Visible = false; this.Label5.Visible = false; this.Label6.Visible = false;
                this.Label7.Visible = false;

                this.LabelOcenyKomunikat.Visible = false;
            }
        }


        protected void DropDownListOcenyPrzedmiot_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LabelWybranyPrzedmiot.Text = DropDownListOcenyPrzedmiot.SelectedItem.Text;

            if (DropDownListOcenyPrzedmiot.SelectedIndex == 0)
            {
                this.Label1.Visible = false; this.Label2.Visible = false; this.Label3.Visible = false;
                this.Label4.Visible = false; this.Label5.Visible = false; this.Label6.Visible = false;
                this.Label7.Visible = false;
                this.LabelOcenyKomunikat.Visible = false;
            }
            else
            {
                this.Label1.Visible = true;
                this.LabelOcenyKomunikat.Visible = false;
            }
        }


        protected void DropDownListOcenyKlasa_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownListOcenyKlasa.SelectedIndex != 0)
            {
                try
                {
                    //załadowanie danych z bazy do DropDownListOcenyUczen z wykorzystaniem filtrowania z DropDownListOcenyKlasa
                    int idKlasy = Convert.ToInt32(DropDownListOcenyKlasa.SelectedValue.ToString());
                    var uczen = from c in entitycontext.Uczniowie
                                where c.IdKlasy == idKlasy
                                select new { c.IdUcznia, uczenImieNazwisko = c.Imie + " " + c.Nazwisko };

                    DropDownListOcenyUczen.DataSource = uczen.ToList();
                    DropDownListOcenyUczen.Enabled = true;
                    DropDownListOcenyUczen.DataValueField = "IdUcznia";
                    DropDownListOcenyUczen.DataTextField = "uczenImieNazwisko";
                    DropDownListOcenyUczen.DataBind();
                    DropDownListOcenyUczen.Items.Insert(0, "--Wybierz--");
                    this.LabelWybranaKlasa.Text = DropDownListOcenyKlasa.SelectedItem.Text;
                    this.LabelWybranyUczen.Text = "";
                    this.LabelOcenyKomunikat.Visible = false;
                }
                catch
                {
                }

                if (DropDownListOcenyKlasa.SelectedIndex == 0)
                {
                    try
                    {
                        this.Label2.Visible = false; this.Label3.Visible = false; this.Label4.Visible = false;
                        this.Label5.Visible = false; this.Label6.Visible = false; this.Label7.Visible = false;
                        this.LabelOcenyKomunikat.Visible = false;
                    }
                    catch
                    {
                    }
                }
                else
                {
                    this.Label1.Visible = true; this.Label2.Visible = true;
                    this.LabelOcenyKomunikat.Visible = false;
                }
            }
        }


        protected void DropDownListOcenyUczen_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LabelWybranyUczen.Text = DropDownListOcenyUczen.SelectedItem.Text;

            if (DropDownListOcenyUczen.SelectedIndex == 0)
            {
                this.Label3.Visible = false; this.Label4.Visible = false; this.Label5.Visible = false; 
                this.Label6.Visible = false; this.Label7.Visible = false;
                this.LabelOcenyKomunikat.Visible = false;
            }
            else
            {
                this.Label1.Visible = true; this.Label2.Visible = true;
                this.Label3.Visible = true; this.Label4.Visible = true;
                this.LabelOcenyKomunikat.Visible = false;
            }
        }


        protected void DropDownListOcenyRodzajOceny_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LabelWybranyRodzajOceny.Text = DropDownListOcenyRodzajOceny.SelectedItem.Text;

            if (DropDownListOcenyRodzajOceny.SelectedIndex == 0)
            {
                this.Label5.Visible = false; this.Label6.Visible = false; this.Label7.Visible = false;
                this.LabelOcenyKomunikat.Visible = false;
            }
            else
            {
                this.Label1.Visible = true; this.Label2.Visible = true; this.Label3.Visible = true;
                this.Label4.Visible = true; this.Label5.Visible = true;
                this.LabelOcenyKomunikat.Visible = false;
            }
        }


        protected void DropDownListOcenyOcena_SelectedIndexChanged(object sender, EventArgs e)
        {   
            //Wyświetlenie wybranych wartości w Labelach przed zapisaniem oceny do bazy
            this.LabelWybranyPrzedmiot.Text = DropDownListOcenyPrzedmiot.SelectedItem.Text;
            this.LabelWybranaKlasa.Text = DropDownListOcenyKlasa.SelectedItem.Text;
            this.LabelWybranyUczen.Text = DropDownListOcenyUczen.SelectedItem.Text;
            this.LabelWybranyRodzajOceny.Text = DropDownListOcenyRodzajOceny.SelectedItem.Text;
            this.LabelWybranaOcena.Text = DropDownListOcenyOcena.SelectedItem.Text;

            if (DropDownListOcenyOcena.SelectedIndex == 0)
            {
                this.Label6.Visible = false; this.Label7.Visible = false;
                this.LabelOcenyKomunikat.Visible = false;
            }
            else
            {
                this.Label1.Visible = true; this.Label2.Visible = true; this.Label3.Visible = true;
                this.Label4.Visible = true; this.Label5.Visible = true; this.Label6.Visible = true; 
                this.Label7.Visible = true;
                this.LabelOcenyKomunikat.Visible = false;
            }
        }


        protected void ButtonZatwierdzOcene_Click(object sender, EventArgs e)
        {
            string guidUzytkownikaString = Membership.GetUser().ProviderUserKey.ToString();   //Pobieranie UserID rejestrowanego użytkownika do tabeli Nauczyciele/Uczniowie/RodziceOpiekunowie
            Guid gu = new Guid(guidUzytkownikaString);

            string nauczycielUserName = (from h in entitycontext.Nauczyciele  //Pobieranie loginu (UserName) zalogowanego nauczyciela
                                        where h.UserId == gu
                                        select h.UserName).FirstOrDefault();
                                        //select new { h.UserName, h.IdNauczyciela, nauczycielImieNazwisko = h.Imie + " " + h.Nazwisko };

            string nauczycielNazwisko = (from h in entitycontext.Nauczyciele  //Pobieranie Nazwiska zalogowanego nauczyciela
                                         where h.UserId == gu
                                         select h.Nazwisko).FirstOrDefault();

            int intNauczycielId = (from h in entitycontext.Nauczyciele  //Pobieranie Id zalogowanego nauczyciela
                                where h.UserId == gu
                                select h.IdNauczyciela).FirstOrDefault();


            if (DropDownListOcenyPrzedmiot.SelectedIndex != 0 && DropDownListOcenyKlasa.SelectedIndex != 0 &&
                DropDownListOcenyUczen.SelectedIndex != 0 && DropDownListOcenyRodzajOceny.SelectedIndex != 0 && DropDownListOcenyOcena.SelectedIndex != 0)
            {
                try
                {
                    int ocenyIdNauczyciela = intNauczycielId;   //IdNauczyciela wystawiającego ocenę do zapisania w tabeli Oceny
                    int ocenyIdUcznia = Convert.ToInt32(DropDownListOcenyUczen.SelectedValue.ToString());   //Pobranie IdUcznia z dropdownlist do zapisania w tabeli Oceny
                    var varocenyIdKlasy = (from x in entitycontext.Uczniowie     //Pobranie IdKlasy wg IdUcznia
                                           where x.IdUcznia == ocenyIdUcznia     //jw.
                                           select x.IdKlasy).FirstOrDefault();   //jw.
                    int ocenyIdKlasy = Convert.ToInt32(varocenyIdKlasy);         //jw.
                    int ocenyIdRodzajuOceny = Convert.ToInt32(DropDownListOcenyRodzajOceny.SelectedValue.ToString());   //Pobranie IdRodzajuOceny z dropdownlist do zapisania w tabeli Oceny
                    int ocenyIdPrzedmiotu = Convert.ToInt32(DropDownListOcenyPrzedmiot.SelectedValue.ToString());   //Pobranie IdPrzedmiotu z dropdownlist do zapisania w tabeli Oceny
                    decimal ocenyOcena = Convert.ToDecimal(DropDownListOcenyOcena.SelectedValue.ToString());   //Pobranie Oceny z dropdownlist do zapisania w tabeli Oceny
                    DateTime ocenyData = DateTime.Now;   //Data wystawienia oceny
                    string ocenaWidok = DropDownListOcenyOcena.SelectedValue.ToString();

                    if (DropDownListOcenyOcena.SelectedValue == "6,00") { ocenaWidok = "6"; }
                    if (DropDownListOcenyOcena.SelectedValue == "5,67") { ocenaWidok = "-6"; }
                    if (DropDownListOcenyOcena.SelectedValue == "5,33") { ocenaWidok = "5+"; }
                    if (DropDownListOcenyOcena.SelectedValue == "5,00") { ocenaWidok = "5"; }
                    if (DropDownListOcenyOcena.SelectedValue == "4,67") { ocenaWidok = "-5"; }
                    if (DropDownListOcenyOcena.SelectedValue == "4,33") { ocenaWidok = "4+"; }
                    if (DropDownListOcenyOcena.SelectedValue == "4,00") { ocenaWidok = "4"; }
                    if (DropDownListOcenyOcena.SelectedValue == "3,67") { ocenaWidok = "-4"; }
                    if (DropDownListOcenyOcena.SelectedValue == "3,33") { ocenaWidok = "3+"; }
                    if (DropDownListOcenyOcena.SelectedValue == "3,00") { ocenaWidok = "3"; }
                    if (DropDownListOcenyOcena.SelectedValue == "2,67") { ocenaWidok = "-3"; }
                    if (DropDownListOcenyOcena.SelectedValue == "2,33") { ocenaWidok = "2+"; }
                    if (DropDownListOcenyOcena.SelectedValue == "2,00") { ocenaWidok = "2"; }
                    if (DropDownListOcenyOcena.SelectedValue == "1,67") { ocenaWidok = "-2"; }
                    if (DropDownListOcenyOcena.SelectedValue == "1,33") { ocenaWidok = "1+"; }
                    if (DropDownListOcenyOcena.SelectedValue == "1,00") { ocenaWidok = "1"; }

                    Oceny ocena = new Oceny();
                    ocena.Ocena = ocenyOcena;
                    ocena.OcenaWidok = ocenaWidok;
                    ocena.Data = ocenyData;
                    ocena.IdUcznia = ocenyIdUcznia;
                    ocena.IdKlasy = ocenyIdKlasy;
                    ocena.IdNauczyciela = ocenyIdNauczyciela;
                    ocena.IdRodzajuOceny = ocenyIdRodzajuOceny;
                    ocena.IdPrzedmiotu = ocenyIdPrzedmiotu;
                    entitycontext.Oceny.Add(ocena);
                    entitycontext.SaveChanges();
                    entitycontext.Dispose();

                    string continueUrl = "/WyborPoOcenie.aspx";
                    Response.Redirect(continueUrl); 
                }
                catch
                {
                    this.LabelOcenyKomunikat.Visible = true;
                    this.LabelOcenyKomunikat.Text = "Błąd, sprawdź czy wszystkie pola zostały poprawnie uzupełnione!";
                }
            }
            else
            {
                this.LabelOcenyKomunikat.Visible = true;
                this.LabelOcenyKomunikat.Text = "Błąd, sprawdź czy wszystkie pola zostały uzupełnione!";
            }
        }
    }
}