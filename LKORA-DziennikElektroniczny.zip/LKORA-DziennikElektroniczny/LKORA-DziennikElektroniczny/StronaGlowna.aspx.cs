﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LKORA_DziennikElektroniczny
{
    public partial class StronaGlowna : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (EntitiesDziennik context = new EntitiesDziennik())
            {
                var aktualnosci = context.ProcedureAktualnosci();
                Repeater1.DataSource = aktualnosci.ToList();
                DataBind();
            }
        }


        protected void Repeater1_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {

        }
    }
}