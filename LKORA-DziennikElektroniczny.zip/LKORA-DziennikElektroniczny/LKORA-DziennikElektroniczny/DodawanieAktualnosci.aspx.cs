﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LKORA_DziennikElektroniczny
{
    public partial class DodawanieAktualnosci : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }


        protected void ButtonDodajAktualnosci_Click(object sender, EventArgs e)
        {
            string stringCzyZdjecie = FileUploadAktualnosciZdjecie.FileName;
            string stringCzyLinkZewnetrzny = TextBoxAktualnosciLinkZewnetrzny.Text;
            String filePath = Server.MapPath(@"~/Images/AktualnosciZdjecia/" + FileUploadAktualnosciZdjecie.FileName);
            using (EntitiesDziennik context = new EntitiesDziennik())

                if (stringCzyZdjecie != "")   //Jeżeli dodano zdjęcie
                {
                    if (stringCzyLinkZewnetrzny != "")   //Jeżeli dodano link zewnetrzny
                    {
                        try
                        {
                            Aktualnosci aktualnosc = new Aktualnosci();
                            aktualnosc.AktualnosciTytul = this.TextBoxAktualnosciTytul.Text;
                            aktualnosc.AktualnosciTresc = this.TextBoxAktualnosciTresc.Text;
                            aktualnosc.AktualnosciZdjecie = "../Images/AktualnosciZdjecia/" + FileUploadAktualnosciZdjecie.FileName;
                            aktualnosc.AktualnosciLinkZewnetrzny = this.TextBoxAktualnosciLinkZewnetrzny.Text;
                            context.Aktualnosci.Add(aktualnosc);
                            context.SaveChanges();
                            FileUploadAktualnosciZdjecie.SaveAs(filePath);
                            this.LabelDodanieAktualnosci.Text = "Treść aktualności została zapisana!";
                            this.TextBoxAktualnosciTytul.Text = String.Empty;
                            this.TextBoxAktualnosciTresc.Text = String.Empty;
                            this.TextBoxAktualnosciLinkZewnetrzny.Text = String.Empty;
                        }
                        catch
                        {
                            this.LabelDodanieAktualnosci.Text = "Błąd!";
                        }
                    }

                    else   //Jeżeli dodano zdjęcie i nie dodano linku zewnetrznego
                    {
                        try
                        {
                            Aktualnosci aktualnosc = new Aktualnosci();
                            aktualnosc.AktualnosciTytul = this.TextBoxAktualnosciTytul.Text;
                            aktualnosc.AktualnosciTresc = this.TextBoxAktualnosciTresc.Text;
                            aktualnosc.AktualnosciZdjecie = "../Images/AktualnosciZdjecia/" + FileUploadAktualnosciZdjecie.FileName;
                            //aktualnosc.AktualnosciLinkZewnetrzny = this.TextBoxAktualnosciLinkZewnetrzny.Text;
                            context.Aktualnosci.Add(aktualnosc);
                            context.SaveChanges();
                            FileUploadAktualnosciZdjecie.SaveAs(filePath);
                            this.LabelDodanieAktualnosci.Text = "Treść aktualności została zapisana!";
                            this.TextBoxAktualnosciTytul.Text = String.Empty;
                            this.TextBoxAktualnosciTresc.Text = String.Empty;
                        }
                        catch
                        {
                            this.LabelDodanieAktualnosci.Text = "Błąd!";
                        }
                    }
                }

                else   //Jeżeli nie dodano zdjecia
                {
                    if (stringCzyLinkZewnetrzny != "")   //Jeżeli dodano link zewnetrzny
                    {
                        try
                        {
                            Aktualnosci aktualnosc = new Aktualnosci();
                            aktualnosc.AktualnosciTytul = this.TextBoxAktualnosciTytul.Text;
                            aktualnosc.AktualnosciTresc = this.TextBoxAktualnosciTresc.Text;
                            aktualnosc.AktualnosciZdjecie = "../Images/AktualnosciZdjecia/ImageZastepczy.jpg";
                            aktualnosc.AktualnosciLinkZewnetrzny = this.TextBoxAktualnosciLinkZewnetrzny.Text;
                            context.Aktualnosci.Add(aktualnosc);
                            context.SaveChanges();
                            this.LabelDodanieAktualnosci.Text = "Treść aktualności została zapisana!";
                            this.TextBoxAktualnosciTytul.Text = String.Empty;
                            this.TextBoxAktualnosciTresc.Text = String.Empty;
                            this.TextBoxAktualnosciLinkZewnetrzny.Text = String.Empty;
                        }
                        catch
                        {
                            this.LabelDodanieAktualnosci.Text = "Błąd!";
                        }
                    }

                    else   //Jeżeli nie dodano zdjecia i nie dodano linku zewnetrznego
                    {
                        try
                        {
                            Aktualnosci aktualnosc = new Aktualnosci();
                            aktualnosc.AktualnosciTytul = this.TextBoxAktualnosciTytul.Text;
                            aktualnosc.AktualnosciTresc = this.TextBoxAktualnosciTresc.Text;
                            aktualnosc.AktualnosciZdjecie = "../Images/AktualnosciZdjecia/ImageZastepczy.jpg";
                            //aktualnosc.AktualnosciLinkZewnetrzny = this.TextBoxAktualnosciLinkZewnetrzny.Text;
                            context.Aktualnosci.Add(aktualnosc);
                            context.SaveChanges();
                            this.LabelDodanieAktualnosci.Text = "Treść aktualności została zapisana!";
                            this.TextBoxAktualnosciTytul.Text = String.Empty;
                            this.TextBoxAktualnosciTresc.Text = String.Empty;
                        }
                        catch
                        {
                            this.LabelDodanieAktualnosci.Text = "Błąd!";
                        }
                    }
                }
        }
    }
}