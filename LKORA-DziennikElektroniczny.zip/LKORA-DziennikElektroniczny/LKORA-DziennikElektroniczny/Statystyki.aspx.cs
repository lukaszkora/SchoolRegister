﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LKORA_DziennikElektroniczny
{
    public partial class Statystyki : System.Web.UI.Page
    {
        EntitiesDziennik entitycontext = new EntitiesDziennik();
        SqlDataSource sqlcontext = new SqlDataSource();

        protected void Page_Load(object sender, EventArgs e)
        {
            var avgOcenyWszystkie =
                    (from a in entitycontext.Oceny
                     select a.Ocena).Average();
            double dblavgOcenyWszystkie = Math.Round(Convert.ToDouble(avgOcenyWszystkie), 2);
            string stravgOcenyWszystkie = dblavgOcenyWszystkie.ToString();
            this.LabelSredniaWszystko.Text = stravgOcenyWszystkie;

            var avgOcenyPolski =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 1
                 select b.Ocena).Average();
            double dblavgOcenyPolski = Math.Round(Convert.ToDouble(avgOcenyPolski), 2);
            string stravgOcenyPolski = dblavgOcenyPolski.ToString();
            this.LabelSredniaPolski.Text = stravgOcenyPolski;

            var avgOcenyAngielski =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 2
                 select b.Ocena).Average();
            double dblavgOcenyAngielski = Math.Round(Convert.ToDouble(avgOcenyAngielski), 2);
            string stravgOcenyAngielski = dblavgOcenyAngielski.ToString();
            this.LabelSredniaAngielski.Text = stravgOcenyAngielski;

            var avgOcenyMatematyka =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 3
                 select b.Ocena).Average();
            double dblavgOcenyMatematyka = Math.Round(Convert.ToDouble(avgOcenyMatematyka), 2);
            string stravgOcenyMatematyka = dblavgOcenyMatematyka.ToString();
            this.LabelSredniaMatematyka.Text = stravgOcenyMatematyka;

            var avgOcenyInformatyka =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 4
                 select b.Ocena).Average();
            double dblavgOcenyInformatyka = Math.Round(Convert.ToDouble(avgOcenyInformatyka), 2);
            string stravgOcenyInformatyka = dblavgOcenyInformatyka.ToString();
            this.LabelSredniaInformatyka.Text = stravgOcenyInformatyka;

            var avgOcenyHistoria =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 5
                 select b.Ocena).Average();
            double dblavgOcenyHistoria = Math.Round(Convert.ToDouble(avgOcenyHistoria), 2);
            string stravgOcenyHistoria = dblavgOcenyHistoria.ToString();
            this.LabelSredniaHistoria.Text = stravgOcenyHistoria;

            var avgOcenyPlastyka =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 6
                 select b.Ocena).Average();
            double dblavgOcenyPlastyka = Math.Round(Convert.ToDouble(avgOcenyPlastyka), 2);
            string stravgOcenyPlastyka = dblavgOcenyPlastyka.ToString();
            this.LabelSredniaPlastyka.Text = stravgOcenyPlastyka;

            var avgOcenyTechnika =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 7
                 select b.Ocena).Average();
            double dblavgOcenyTechnika = Math.Round(Convert.ToDouble(avgOcenyTechnika), 2);
            string stravgOcenyTechnika = dblavgOcenyTechnika.ToString();
            this.LabelSredniaTechnika.Text = stravgOcenyTechnika;

            var avgOcenyMuzyka =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 8
                 select b.Ocena).Average();
            double dblavgOcenyMuzyka = Math.Round(Convert.ToDouble(avgOcenyMuzyka), 2);
            string stravgOcenyMuzyka = dblavgOcenyMuzyka.ToString();
            this.LabelSredniaMuzyka.Text = stravgOcenyMuzyka;

            var avgOcenyPrzyroda =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 9
                 select b.Ocena).Average();
            double dblavgOcenyPrzyroda = Math.Round(Convert.ToDouble(avgOcenyPrzyroda), 2);
            string stravgOcenyPrzyroda = dblavgOcenyPrzyroda.ToString();
            this.LabelSredniaPrzyroda.Text = stravgOcenyPrzyroda;

            var avgOcenyReligia =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 10
                 select b.Ocena).Average();
            double dblavgOcenyReligia = Math.Round(Convert.ToDouble(avgOcenyReligia), 2);
            string stravgOcenyReligia = dblavgOcenyReligia.ToString();
            this.LabelSredniaReligia.Text = stravgOcenyReligia;

            var avgOcenyWf =
                (from b in entitycontext.Oceny
                 where b.IdPrzedmiotu == 11
                 select b.Ocena).Average();
            double dblavgOcenyWf = Math.Round(Convert.ToDouble(avgOcenyWf), 2);
            string stravgOcenyWf = dblavgOcenyWf.ToString();
            this.LabelSredniaWf.Text = stravgOcenyWf;


            //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX


            if (!IsPostBack)
            {
                //załadowanie danych z bazy do DropDownListStatystykiPrzedmiot
                var przedmiot = from a in entitycontext.Przedmioty select new { a.IdPrzedmiotu, a.NazwaPrzedmiotu };
                DropDownListStatystykiPrzedmiot.DataSource = przedmiot.ToList();
                DropDownListStatystykiPrzedmiot.DataValueField = "IdPrzedmiotu";
                DropDownListStatystykiPrzedmiot.DataTextField = "NazwaPrzedmiotu";
                DropDownListStatystykiPrzedmiot.DataBind();
                DropDownListStatystykiPrzedmiot.Items.Insert(0, "--Wybierz przedmiot--");

                //załadowanie danych z bazy do DropDownListStatystykiKlasa
                var klasa = from b in entitycontext.Klasy select new { b.IdKlasy, b.NazwaKlasy };
                DropDownListStatystykiKlasa.DataSource = klasa.ToList();
                DropDownListStatystykiKlasa.Enabled = true;
                DropDownListStatystykiKlasa.DataValueField = "IdKlasy";
                DropDownListStatystykiKlasa.DataTextField = "NazwaKlasy";
                DropDownListStatystykiKlasa.DataBind();
                DropDownListStatystykiKlasa.Items.Insert(0, "--Wybierz klasę--");
                //    DropDownListStatystykiKlasa.Enabled = false;

                //załadowanie danych z bazy do DropDownListStatystykiUczen
                var uczen = from c in entitycontext.Uczniowie select new { c.IdUcznia, uczenImieNazwisko = c.Imie + " " + c.Nazwisko };
                DropDownListStatystykiUczen.DataSource = uczen.ToList();
                DropDownListStatystykiUczen.Enabled = true;
                DropDownListStatystykiUczen.DataValueField = "IdUcznia";
                DropDownListStatystykiUczen.DataTextField = "uczenImieNazwisko";
                DropDownListStatystykiUczen.DataBind();
                DropDownListStatystykiUczen.Items.Insert(0, "--Wybierz ucznia--");
            }
        }



        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX



        //DOKONANO WYBORU PRZEDMIOTU
        protected void DropDownListStatystykiPrzedmiot_SelectedIndexChanged(object sender, EventArgs e)   
        {          
            if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0)
            {
                try
                {
                    int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());

                    //JEŻELI WYBRANO TYLKO PRZEDMIOT, NASTĄPI WYLICZENIE ŚREDNIEJ DLA TEGO PRZEDMIOTU
                    if (DropDownListStatystykiKlasa.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                    {
                        try
                        {
                            //int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                            var avgPrzedmiot = (from f in entitycontext.Oceny
                                                where f.IdPrzedmiotu == idPrzedmiotu
                                                select f.Ocena).Average();
                            double dblavgPrzedmiot = Math.Round(Convert.ToDouble(avgPrzedmiot), 2);
                            string stravgPrzedmiot = dblavgPrzedmiot.ToString();
                            this.LabelWynik.Text = stravgPrzedmiot;
                            this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO PRZEDMIOT I KLASĘ, NASTĄPI WYLICZENIE ŚREDNIEJ OCEN Z PRZEDMIOTU DLA TEJ KLASY
                    if (DropDownListStatystykiKlasa.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                    {
                        try
                        {
                            //ZAŁADOWANIE DANYCH DO DropDownListUczen NA PODSTAWIE WYBORU Z DropDownListKlasa
                            int idKlasy = Convert.ToInt32(DropDownListStatystykiKlasa.SelectedValue.ToString());
                            var uczen = from c in entitycontext.Uczniowie
                                        where c.IdKlasy == idKlasy
                                        select new { c.IdUcznia, uczenImieNazwisko = c.Imie + " " + c.Nazwisko };

                            DropDownListStatystykiUczen.DataSource = uczen.ToList();
                            //DropDownListStatystykiUczen.Enabled = true;
                            DropDownListStatystykiUczen.DataValueField = "IdUcznia";
                            DropDownListStatystykiUczen.DataTextField = "uczenImieNazwisko";
                            DropDownListStatystykiUczen.DataBind();
                            DropDownListStatystykiUczen.Items.Insert(0, "--Wybierz--");

                            //int idKlasy = Convert.ToInt32(DropDownListStatystykiKlasa.SelectedValue.ToString());
                            var avgPrzedmiotKlasa = (from g in entitycontext.Oceny
                                                     where g.IdPrzedmiotu == idPrzedmiotu
                                                     && g.IdKlasy == idKlasy
                                                     select g.Ocena).Average();
                            double dblavgPrzedmiotKlasa = Math.Round(Convert.ToDouble(avgPrzedmiotKlasa), 2);
                            string stravgPrzedmiotKlasa = dblavgPrzedmiotKlasa.ToString();
                            this.LabelWynik.Text = stravgPrzedmiotKlasa;
                            this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu dla danej klasy wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO PRZEDMIOT, KLASĘ I UCZNIA, NASTĄPI WYLICZENIE ŚREDNIEJ Z PRZEDMIOTU DLA TEGO UCZNIA
                    if (DropDownListStatystykiKlasa.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex != 0)
                    {
                        try
                        {
                            int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                            var avgPrzedmiotUczen = (from h in entitycontext.Oceny
                                                     where h.IdPrzedmiotu == idPrzedmiotu
                                                     && h.IdUcznia == idUcznia
                                                     select h.Ocena).Average();
                            double dblavgPrzedmiotUczen = Math.Round(Convert.ToDouble(avgPrzedmiotUczen), 2);
                            string stravgPrzedmiotUczen = dblavgPrzedmiotUczen.ToString();
                            this.LabelWynik.Text = stravgPrzedmiotUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu dla danego ucznia wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO PRZEDMIOT I UCZNIA (BEZ KLASY), NASTĄPI WYLICZENIE ŚREDNIEJ Z PRZEDMIOTU DLA TEGO UCZNIA
                    if (DropDownListStatystykiKlasa.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex != 0)   
                    {
                        try
                        {
                            int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                            var avgPrzedmiotUczen = (from h in entitycontext.Oceny
                                                     where h.IdPrzedmiotu == idPrzedmiotu
                                                     && h.IdUcznia == idUcznia
                                                     select h.Ocena).Average();
                            double dblavgPrzedmiotUczen = Math.Round(Convert.ToDouble(avgPrzedmiotUczen), 2);
                            string stravgPrzedmiotUczen = dblavgPrzedmiotUczen.ToString();
                            this.LabelWynik.Text = stravgPrzedmiotUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu dla danego ucznia wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }
                }

                catch
                {
                    this.LabelWynik.Text = "";
                    this.LabelWynikTxt.Text = "";
                }
            }

            //JEŻELI NIE WYBRANO PRZEDMIOTU
            else if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0)
            {
                //JEŻELI NIE WYBRANO NICZEGO
                if (DropDownListStatystykiKlasa.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                {
                    try
                    {
                        this.LabelWynik.Text = "";
                        this.LabelWynikTxt.Text = "";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO TYLKO KLASĘ (BEZ PRZEDMIOTU I UCZNIA), NASTĄPI WYLICZENIE ŚREDNIEJ DLA TEJ KLASY
                if (DropDownListStatystykiKlasa.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                {
                    try
                    {
                        int idKlasy = Convert.ToInt32(DropDownListStatystykiKlasa.SelectedValue.ToString());
                        var avgKlasa = (from g in entitycontext.Oceny
                                        where g.IdKlasy == idKlasy
                                        select g.Ocena).Average();
                        double dblavgKlasa = Math.Round(Convert.ToDouble(avgKlasa), 2);
                        string stravgKlasa = dblavgKlasa.ToString();
                        this.LabelWynik.Text = stravgKlasa;
                        this.LabelWynikTxt.Text = "Średnia ocen wybranej klasy wynosi: &nbsp";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO UCZNIA I KLASĘ (BEZ PRZEDMIOTU), NASTĄPI WYLICZENIE ŚREDNIEJ DLA TEGO UCZNIA
                if (DropDownListStatystykiKlasa.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex != 0)   
                {
                    try
                    {
                        int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                        var avgUczen = (from h in entitycontext.Oceny
                                        where h.IdUcznia == idUcznia
                                        select h.Ocena).Average();
                        double dblavgUczen = Math.Round(Convert.ToDouble(avgUczen), 2);
                        string stravgUczen = dblavgUczen.ToString();
                        this.LabelWynik.Text = stravgUczen;
                        this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia wynosi: &nbsp";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO TYLKO UCZNIA (BEZ PRZEDMIOTU I KLASY), NASTĄPI WYLICZENIE ŚREDNIEJ DLA TEGO UCZNIA
                if (DropDownListStatystykiKlasa.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex != 0)   
                {
                    try
                    {
                        int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                        var avgUczen = (from h in entitycontext.Oceny
                                        where h.IdUcznia == idUcznia
                                        select h.Ocena).Average();
                        double dblavgUczen = Math.Round(Convert.ToDouble(avgUczen), 2);
                        string stravgUczen = dblavgUczen.ToString();
                        this.LabelWynik.Text = stravgUczen;
                        this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia wynosi: &nbsp";
                    }
                    catch
                    {
                    }
                }

            }
        }
        //KONIEC DropDownListStatystykiPrzedmiot



        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX



        //DOKONANO WYBORU KLASY
        protected void DropDownListStatystykiKlasa_SelectedIndexChanged(object sender, EventArgs e)   
        {
            if (DropDownListStatystykiKlasa.SelectedIndex != 0)
            {
                try
                {
                    int idKlasy = Convert.ToInt32(DropDownListStatystykiKlasa.SelectedValue.ToString());

                    //ZAŁADOWANIE DANYCH DO DropDownListUczen NA PODSTAWIE WYBORU Z DropDownListKlasa
                    var uczen = from c in entitycontext.Uczniowie
                                where c.IdKlasy == idKlasy
                                select new { c.IdUcznia, uczenImieNazwisko = c.Imie + " " + c.Nazwisko };

                    DropDownListStatystykiUczen.DataSource = uczen.ToList();
                    //DropDownListStatystykiUczen.Enabled = true;
                    DropDownListStatystykiUczen.DataValueField = "IdUcznia";
                    DropDownListStatystykiUczen.DataTextField = "uczenImieNazwisko";
                    DropDownListStatystykiUczen.DataBind();
                    DropDownListStatystykiUczen.Items.Insert(0, "--Wybierz--");

                    //JEŻELI WYBRANO TYLKO KLASĘ (BEZ PRZEDMIOTU I UCZNIA), NASTĄPI WYLICZENIE ŚREDNIEJ ZE WSZYSTKICH PRZEDMIOTÓW DLA TEJ KLASY
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                    {
                        try
                        {
                            var avgKlasa = (from g in entitycontext.Oceny
                                    where g.IdKlasy == idKlasy
                                    select g.Ocena).Average();
                            double dblavgKlasa = Math.Round(Convert.ToDouble(avgKlasa), 2);
                            string stravgKlasa = dblavgKlasa.ToString();
                            this.LabelWynik.Text = stravgKlasa;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranej klasy wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO KLASĘ I PRZEDMIOT (BEZ UCZNIA), NASTĄPI WYLICZENIE ŚREDNIEJ OCEN Z PRZEDMIOTU DLA TEJ KLASY
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                    {
                        try
                        {
                            int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                            var avgKlasaPrzedmiot = (from i in entitycontext.Oceny
                                                     where i.IdKlasy == idKlasy
                                                     && i.IdPrzedmiotu == idPrzedmiotu
                                                     select i.Ocena).Average();
                            double dblavgKlasaPrzedmiot = Math.Round(Convert.ToDouble(avgKlasaPrzedmiot), 2);
                            string stravgKlasaPrzedmiot = dblavgKlasaPrzedmiot.ToString();
                            this.LabelWynik.Text = stravgKlasaPrzedmiot;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranej klasy z danego przedmiotu wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO KLASĘ, UCZNIA I PRZEDMIOT NASTĄPI WYLICZENIE ŚREDNIEJ Z PRZEDMIOTU DLA TEGO UCZNIA
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex != 0)   
                    {
                        try
                        {
                            int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                            int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                            var avgPrzedmiotUczen = (from h in entitycontext.Oceny
                                                     where h.IdPrzedmiotu == idPrzedmiotu
                                                     && h.IdUcznia == idUcznia
                                                     select h.Ocena).Average();
                            double dblavgPrzedmiotUczen = Math.Round(Convert.ToDouble(avgPrzedmiotUczen), 2);
                            string stravgPrzedmiotUczen = dblavgPrzedmiotUczen.ToString();
                            this.LabelWynik.Text = stravgPrzedmiotUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia z danego przedmiotu wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO KLASĘ I UCZNIA (BEZ PRZEDMIOTU) NASTĄPI WYLICZENIE ŚREDNIEJ DLA TEGO UCZNIA
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex != 0)   
                    {
                        try
                        {
                            int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                            var avgUczen = (from h in entitycontext.Oceny
                                            where h.IdUcznia == idUcznia
                                            select h.Ocena).Average();
                            double dblavgUczen = Math.Round(Convert.ToDouble(avgUczen), 2);
                            string stravgUczen = dblavgUczen.ToString();
                            this.LabelWynik.Text = stravgUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                }
                catch
                {
                }

            }

            //JEŻELI NIE WYBRANO KLASY
            else if (DropDownListStatystykiKlasa.SelectedIndex == 0)
            {
                //JEŻELI NIE WYBRANO NICZEGO
                if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                {
                    try
                    {
                        this.LabelWynik.Text = "";
                        this.LabelWynikTxt.Text = "";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO TYLKO PRZEDMIOT, NASTĄPI WYLICZENIE ŚREDNIEJ DLA TEGO PRZEDMIOTU
                if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex == 0)   
                {
                    try
                    {
                        int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                        var avgPrzedmiot = (from f in entitycontext.Oceny
                                            where f.IdPrzedmiotu == idPrzedmiotu
                                            select f.Ocena).Average();
                        double dblavgPrzedmiot = Math.Round(Convert.ToDouble(avgPrzedmiot), 2);
                        string stravgPrzedmiot = dblavgPrzedmiot.ToString();
                        this.LabelWynik.Text = stravgPrzedmiot;
                        this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu wynosi: &nbsp";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO PRZEDMIOT I UCZNIA(BEZ KLASY), NASTĄPI WYLICZENIE ŚREDNIEJ Z PRZEDMIOTU DLA TEGO UCZNIA
                if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiUczen.SelectedIndex != 0)
                {
                    int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                    int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                    var avgPrzedmiotUczen = (from h in entitycontext.Oceny
                                             where h.IdPrzedmiotu == idPrzedmiotu
                                             && h.IdUcznia == idUcznia
                                             select h.Ocena).Average();
                    double dblavgPrzedmiotUczen = Math.Round(Convert.ToDouble(avgPrzedmiotUczen), 2);
                    string stravgPrzedmiotUczen = dblavgPrzedmiotUczen.ToString();
                    this.LabelWynik.Text = stravgPrzedmiotUczen;
                    this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu dla danego ucznia wynosi: &nbsp";
                }

                //JEŻELI WYBRANO TYLKO UCZNIA (BEZ PRZEDMIOTU I KLASY), NASTĄPI WYLICZENIE ŚREDNIEJ ZE WSZYSTKICH PRZEDMIOTÓW DLA TEGO UCZNIA
                if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiUczen.SelectedIndex != 0)
                {
                    try
                    {
                        int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());
                        var avgUczen = (from h in entitycontext.Oceny
                                        where h.IdUcznia == idUcznia
                                        select h.Ocena).Average();
                        double dblavgUczen = Math.Round(Convert.ToDouble(avgUczen), 2);
                        string stravgUczen = dblavgUczen.ToString();
                        this.LabelWynik.Text = stravgUczen;
                        this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia wynosi: &nbsp";
                    }
                    catch
                    {
                    }
                }


            }
        }
        //KONIEC DropDownListStatystykiKlasa



        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX



        //DOKONANO WYBORU UCZNIA
        protected void DropDownListStatystykiUczen_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownListStatystykiUczen.SelectedIndex != 0)
            {
                try
                {
                    int idUcznia = Convert.ToInt32(DropDownListStatystykiUczen.SelectedValue.ToString());

                    //JEŻELI WYBRANO TYLKO UCZNIA (BEZ PRZEDMIOTU I KLASY), NASTĄPI WYLICZENIE ŚREDNIEJ ZE WSZYSTKICH PRZEDMIOTÓW DLA TEGO UCZNIA
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiKlasa.SelectedIndex == 0)   
                    {
                        try
                        {
                            var avgUczen = (from h in entitycontext.Oceny
                                            where h.IdUcznia == idUcznia
                                            select h.Ocena).Average();
                            double dblavgUczen = Math.Round(Convert.ToDouble(avgUczen), 2);
                            string stravgUczen = dblavgUczen.ToString();
                            this.LabelWynik.Text = stravgUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO UCZNIA I PRZEDMIOT (BEZ KLASY), NASTĄPI WYLICZENIE ŚREDNIEJ Z DANEGO PRZEDMIOTU DLA TEGO UCZNIA
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiKlasa.SelectedIndex == 0)   
                    {
                        try
                        {
                            int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                            var avgPrzedmiotUczen = (from h in entitycontext.Oceny
                                                     where h.IdPrzedmiotu == idPrzedmiotu
                                                     && h.IdUcznia == idUcznia
                                                     select h.Ocena).Average();
                            double dblavgPrzedmiotUczen = Math.Round(Convert.ToDouble(avgPrzedmiotUczen), 2);
                            string stravgPrzedmiotUczen = dblavgPrzedmiotUczen.ToString();
                            this.LabelWynik.Text = stravgPrzedmiotUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia z danego przedmiotu wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO PRZEDMIOT, KLASĘ I UCZNIA, NASTĄPI WYLICZENIE ŚREDNIEJ Z DANEGO PRZEDMIOTU DLA TEGO UCZNIA
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiKlasa.SelectedIndex != 0)   
                    {
                        try
                        {
                            int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                            var avgPrzedmiotUczen = (from h in entitycontext.Oceny
                                                     where h.IdPrzedmiotu == idPrzedmiotu
                                                     && h.IdUcznia == idUcznia
                                                     select h.Ocena).Average();
                            double dblavgPrzedmiotUczen = Math.Round(Convert.ToDouble(avgPrzedmiotUczen), 2);
                            string stravgPrzedmiotUczen = dblavgPrzedmiotUczen.ToString();
                            this.LabelWynik.Text = stravgPrzedmiotUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia z danego przedmiotu wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                    //JEŻELI WYBRANO KLASĘ I UCZNIA (BEZ PRZEDMIOTU), NASTĄPI WYLICZENIE ŚREDNIEJ ZE WSZYSTKICH PRZEDMIOTÓW DLA TEGO UCZNIA
                    if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiKlasa.SelectedIndex != 0)   
                    {
                        try
                        {
                            var avgUczen = (from h in entitycontext.Oceny
                                            where h.IdUcznia == idUcznia
                                            select h.Ocena).Average();
                            double dblavgUczen = Math.Round(Convert.ToDouble(avgUczen), 2);
                            string stravgUczen = dblavgUczen.ToString();
                            this.LabelWynik.Text = stravgUczen;
                            this.LabelWynikTxt.Text = "Średnia ocen wybranego ucznia wynosi: &nbsp";
                        }
                        catch
                        {
                        }
                    }

                }
                catch
                {
                }
            }

            //JEŻELI NIE WYBRANO UCZNIA
            else if (DropDownListStatystykiUczen.SelectedIndex == 0)
            {
                //JEŻELI NIE WYBRANO NICZEGO
                if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiKlasa.SelectedIndex == 0)
                {
                    try
                    {
                        this.LabelWynik.Text = "";
                        this.LabelWynikTxt.Text = "";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO TYLKO PRZEDMIOT (BEZ KLASY I UCZNIA) NASTĄPI WYLICZENIE ŚREDNIEJ Z TEGO PRZEDMIOTU
                if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiKlasa.SelectedIndex == 0)
                {
                    try
                    {
                        int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                        var avgPrzedmiot = (from f in entitycontext.Oceny
                                            where f.IdPrzedmiotu == idPrzedmiotu
                                            select f.Ocena).Average();
                        double dblavgPrzedmiot = Math.Round(Convert.ToDouble(avgPrzedmiot), 2);
                        string stravgPrzedmiot = dblavgPrzedmiot.ToString();
                        this.LabelWynik.Text = stravgPrzedmiot;
                        this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu wynosi: &nbsp";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO PRZEDMIOT I KLASĘ (BEZ UCZNIA) NASTĄPI WYLICZENIE ŚREDNIEJ Z PRZEDMIOTU DLA TEJ KLASY
                if (DropDownListStatystykiPrzedmiot.SelectedIndex != 0 && DropDownListStatystykiKlasa.SelectedIndex != 0)
                {
                    try
                    {
                        int idPrzedmiotu = Convert.ToInt32(DropDownListStatystykiPrzedmiot.SelectedValue.ToString());
                        int idKlasy = Convert.ToInt32(DropDownListStatystykiKlasa.SelectedValue.ToString());
                        var avgPrzedmiotKlasa = (from g in entitycontext.Oceny
                                             where g.IdPrzedmiotu == idPrzedmiotu
                                             && g.IdKlasy == idKlasy
                                             select g.Ocena).Average();
                        double dblavgPrzedmiotKlasa = Math.Round(Convert.ToDouble(avgPrzedmiotKlasa), 2);
                        string stravgPrzedmiotKlasa = dblavgPrzedmiotKlasa.ToString();
                        this.LabelWynik.Text = stravgPrzedmiotKlasa;
                        this.LabelWynikTxt.Text = "Średnia ocen z wybranego przedmiotu dla danej klasy wynosi: &nbsp";
                    }
                    catch
                    {
                    }
                }

                //JEŻELI WYBRANO TYLKO KLASĘ (BEZ PRZEDMIOTU I UCZNIA) NASTĄPI WYLICZENIE ŚREDNIEJ ZE WSZYSTKICH PRZEDMIOTÓW DLA TEJ KLASY
                if (DropDownListStatystykiPrzedmiot.SelectedIndex == 0 && DropDownListStatystykiKlasa.SelectedIndex != 0)
                {
                    try
                    {
                        int idKlasy = Convert.ToInt32(DropDownListStatystykiKlasa.SelectedValue.ToString());
                        var avgKlasa = (from g in entitycontext.Oceny
                                        where g.IdKlasy == idKlasy
                                        select g.Ocena).Average();
                        double dblavgKlasa = Math.Round(Convert.ToDouble(avgKlasa), 2);
                        string stravgKlasa = dblavgKlasa.ToString();
                        this.LabelWynik.Text = stravgKlasa;
                        this.LabelWynikTxt.Text = "Średnia ocen wybranej klasy wynosi: &nbsp";
                    }
                    catch
                    {
                    }

                }
                
            }
        }
        //KONIEC DropDownListStatystykiUczen



        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
        //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX



    }
}